package test.io.Impl;

import test.domain.TradeEntity;
import test.io.TradeInfoReaderWriter;

import java.util.List;

/**
 * Created by K316940 on 04-10-2016.
 */

public class TradeInfoReaderWriterService implements TradeInfoReaderWriter {


    public List<TradeEntity> readTradeInstructions() {
        return null;
    }

    public void writeTradereport() {

    }
}
